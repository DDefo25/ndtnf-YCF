const express = require('express')
const serverless = require('serverless-http')
const getDBClient = require('./db')
const characterSchema = require('./character.schema')

const DB_NAME = 'db1'
const DB_HOSTS = ['rc1c-ds9the2h1f8ed3zn.mdb.yandexcloud.net:27018','rc1d-zk9dut220wixrgt0.mdb.yandexcloud.net:27018']
const DB_USER  = 'user1'
const DB_PASS  = '11111111'
const CACERT   = '.mongodb/root.crt'

const bootstrap = async () => {
  const app = express()
  app.use(express.json())

  const dbClient = await getDBClient({
    DB_NAME,
    DB_HOSTS,
    DB_USER,
    DB_PASS,
    CACERT
  })

  const character = dbClient.model('Character', characterSchema)

  app.get('/api/characters', async (req, res) => {
    const result = await character.find().exec()
    res.json(result);
  })

  app.get('/api/character', async (req, res) => {
    const id = req.query.id
    if (!id) {
      res.status(400).send('Incorrect id')
    }
    const result = await character.findById(id).exec()
    if (!result) {
      res.status(404).send('Character is not found')
    } else {
      res.json(result)
    }
  })

  app.post('/api/character', async (req, res) => {
    const data = req.body
    const newCharacter = await character.create(data)
    res.json(newCharacter);
  })

  return app
}

// ( async () => {
//   console.log('111')
//   const app = await bootstrap()
//   app.listen(3000, () => {
//     console.log('server up')
//   })
// })()

module.exports.handler = async (event, context) => {
  const app = await bootstrap();
  const handler = serverless(app)
  const result = await handler(event, context);
  return result;
};


